<?php
include_once('include/config.php');
if(isset($_POST['submit'])){
	echo "<script>alert('payment done');</script>";
        echo "<script type='text/javascript'> document.location = 'payment.php'; </script>";
}
?>


<!DOCTYPE html>
<html lang="en">

	<head>
		<title>prescription</title>
		
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
		
		<script type="text/javascript">

</script>
		

	</head>

	<body class="medicines"  style="background-color:lightgray;">
		<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4" style="background-color:lightcyan;">
				<div class="logo margin-top-30" style="background-color:lightyellow;">
				<h2>HBR | Patient prescription</h2></a>
				</div>
				<div class="box-register">
					<form name="prescription" id="prescription"  method="post" onSubmit="return valid();">
						<fieldset>
							<legend>
								payment
							</legend>
							
							<div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="card number" placeholder="card number">
									<i class="fa fa-user"></i> </span>
							</div>
							<div class="form-group form-actions">
								<span class="input-icon">
									<input type="password" class="form-control password" name="OTP" placeholder="OTP">
									<i class="fa fa-lock"></i>
									 </span>
							</div>
                                                        <div class="form-group">
								<span class="input-icon">
									<input type="text" class="form-control" name="Amount" placeholder="Amount">
									<i class="fa fa-cash"></i> </span>
							</div>
                                                        <button type="submit" class="btn btn-primary pull-right" id="submit" name="submit">
									Submit <i class="fa fa-arrow-circle-right"></i>
                                                                        
								</button>

                                                        
						</fieldset>
					</form>
                                          
                                               
					<div class="copyright">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> HBR</span>. <span>All rights reserved</span>
					</div>

				</div>

			</div>
		</div>
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<script src="vendor/jquery-validation/jquery.validate.min.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="assets/js/login.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				Login.init();
			});
		</script>
		
	<script>
function userAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#email").val(),
type: "POST",
success:function(data){
$("#user-availability-status1").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>	
	</body>
</html>